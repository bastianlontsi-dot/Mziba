package com.jbzor.mziba_naturelle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
