#-keep class com.github.heywhy.flutter_pusher.** { *; }
#Flutter Wrapper
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }
-keep class org.xmlpull.v1.** { *;}
-dontwarn org.xmlpull.v1.** 
-keep class com.google.firebase.** { *; } 
-dontwarn io.flutter.embedding.**
-ignorewarnings
-keep public class com.google.android.material**  { *; }
#pour une retraçage de la pile d'erreur sans ambiguïté 
-keepattributes LineNumberTable,SourceFile
-renamesourcefileattribute SourceFile